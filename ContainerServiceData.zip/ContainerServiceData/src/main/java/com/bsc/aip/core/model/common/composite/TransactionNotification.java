/*
 * TransactionNotification.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.model.common.composite;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * <HTML> This is the TransactionNotification POJO</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since Oct 25 2016
 */
public class TransactionNotification {

	/** The status. */
	private String status;

	private String statusCode;

	/** The response date time. */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss:SSS", timezone = "PST")
	private Date responseDateTime;

	/** The transaction id. */
	private String transactionId;

	/** The remarks. */
	private Remarks remarks = new Remarks();

	/**
	 * Gets the response date time.
	 *
	 * @return the response date time
	 */
	public Date getResponseDateTime() {
		return responseDateTime;
	}

	/**
	 * Sets the response date time.
	 *
	 * @param responseDateTime
	 *            the new response date time
	 */
	public void setResponseDateTime(Date responseDateTime) {
		this.responseDateTime = responseDateTime;
	}

	/**
	 * Gets the transaction id.
	 *
	 * @return the transaction id
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * Sets the transaction id.
	 *
	 * @param transactionId
	 *            the new transaction id
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status
	 *            the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public Remarks getRemarks() {
		return remarks;
	}

	/**
	 * Sets the remarks.
	 *
	 * @param remarks
	 *            the new remarks
	 */
	public void setRemarks(Remarks remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode
	 *            the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
