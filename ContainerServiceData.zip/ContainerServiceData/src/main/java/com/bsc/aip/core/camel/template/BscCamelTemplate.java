package com.bsc.aip.core.camel.template;

import javax.annotation.Resource;

import org.apache.camel.ProducerTemplate;
import org.springframework.stereotype.Component;

@Component("bscCamelTemplate")
public class BscCamelTemplate {

	@Resource(name = "producerTemplate")
	private ProducerTemplate producerTemplate;

	public ProducerTemplate getProducerTemplate() {
		return producerTemplate;
	}

}
