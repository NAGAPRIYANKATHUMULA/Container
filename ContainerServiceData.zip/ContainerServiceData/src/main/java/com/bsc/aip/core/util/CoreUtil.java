/*
 * LookupserviceUtil.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.util;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.ResponseHeader;

/**
 * <HTML> This class contains utility methods used in the Lookupservice
 * service</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since Oct 25 2016
 */
public class CoreUtil {

	/**
	 * <HTML>
	 * <h1>Method to retrieve the service host</h1>
	 * <p>
	 * </p>
	 * <HTML>
	 *
	 * @return the service host
	 */
	public static String getServiceHost() {

		String hostname = null;

		try {

			hostname = InetAddress.getLocalHost().getHostName();

		} catch (UnknownHostException ex) {
			ex.printStackTrace();
		}

		return hostname;

	}

	/**
	 * <HTML>Method to check whether given Date is in the expected format</HTML>
	 * 
	 * @param date
	 * @param format
	 * @return true if date is in expected format, false otherwise
	 */
	public static boolean isValidDateFormat(String date, String format) {
		boolean isValid = false;

		if (StringUtils.isNotBlank(date) && StringUtils.isNotBlank(format)) {

			SimpleDateFormat formatter = new SimpleDateFormat(format);
			formatter.setLenient(false);
			try {
				formatter.parse(date);
				isValid = true;
			} catch (ParseException e) {
				isValid = false;
			}

		}

		return isValid;
	}

	/**
	 * @param status
	 * @param statusCode
	 * @param response
	 * @param code
	 * @param message
	 * @param desc
	 */
	public static void buildResponse(String status, String statusCode, ResponseHeader responseHeader,
			List<Message> message) {

		if (responseHeader != null) {

			responseHeader.getTransactionNotification().setStatus(status);
			responseHeader.getTransactionNotification().setStatusCode(statusCode);
			responseHeader.getTransactionNotification().setResponseDateTime(new Date());
			responseHeader.getTransactionNotification().getRemarks().getMessages().addAll(message);

		}

	}

	/**
	 * Method to create Message
	 * 
	 * @param code
	 * @param message
	 * @param desc
	 * @return Message
	 */
	public static void addMessage(List<Message> messages, String code, String message, String desc) {

		Message msg = new Message();
		msg.setCode(code);
		msg.setDescription(desc);
		msg.setMessage(message);
		messages.add(msg);
	}

}
