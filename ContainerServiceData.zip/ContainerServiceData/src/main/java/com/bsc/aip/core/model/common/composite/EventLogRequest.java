/*
 * EventLogRequest.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.model.common.composite;

/**
 * <HTML>
 * <h1>Constant class for Event Log Request</h1>
 * <p>
 * This class holds all parameter name for the Event log service request
 * </p>
 * </HTML>
 * 
 * @author AIP
 * @version 1.0
 * @since March 02 2016
 *
 */
public enum EventLogRequest {

	EVENT_ERROR_CODE("eventErrCd"), EVENT_ERROR_DESC("eventErrDesc"), EVENT_ERROR_SEVERITY_CODE("eventErrSevCd"),
	EVENT_EXCEPTION_TRACE("eventExcStackTrac"),PAYLOAD("payload"),TRANSACTION_SOURCE_CODE("tranSSCd"),TRANSACTION_SOURCE_HOST_NAME("tranSrcHstName"),
	BUSINESS_TRANSACTION_TYPE_CODE("busTransTypCd"),BUSINESS_SERVICE_HOSTNAME("busSvcHstNm"),ADDITIONAL_DETAIL("addtlDtlTxt"),
	EVENT_STATUS_CODE("eventStsCd"), TRANSACTION_ID("transactionId"),EVENT_TYPE_CODE("eventTypCd"), EVENT_SUBTYPE_CODE("eventSubTypCd"),
	EVENT_CREATE_TIME("eventCreateTime"),CONTEXT_ID("contextId"), SECOND_CONTEXT_ID("secContextId"),
	THIRD_CONTEXT_ID("thrdContextId"),EVENT_ORIGINATOR_COMPONENT("evntOrigCmpntCd");

	private final String parameter;

	/**
	 * @param s
	 */
	private EventLogRequest(String s) {
		parameter = s;
	}
	
	/**
	 * @return parameter
	 */
	public String getValue(){
		return this.parameter;
	}

	/**
	 * @param otherName
	 * @return true if the given string is equal, false otherwise
	 */
	public boolean equalsName(String otherName) {
		return (otherName == null) ? false : parameter.equals(otherName);
	}

	/* (non-Javadoc)
	 * @see java.lang.Enum#toString()
	 */
	public String toString() {
		return this.parameter;
	}

}
