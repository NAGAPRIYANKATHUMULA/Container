/*
 * LogConfig.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.framewrok.config;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.LoggerConfig;

/**
 * <HTML>This class contains log configuration</HTML>.
 *
 * @author tchawd01
 * @version 1.0
 * @since Sept 22 2016
 */
public class LogConfig {

	/**
	 * Sets the up log4 j.
	 *
	 * @param debugPackages
	 *            the new up log4 j
	 */
	public static void setupLog4J(String debugPackages, String logLevel) {
		try {

			Level level = Level.ERROR;

			if (StringUtils.equalsIgnoreCase(logLevel, Level.DEBUG.name())) {
				level = Level.DEBUG;
			} else if (StringUtils.equalsIgnoreCase(logLevel, Level.INFO.name())) {
				level = Level.INFO;
			} else if (StringUtils.equalsIgnoreCase(logLevel, Level.WARN.name())) {
				level = Level.WARN;
			}

			// Set Log4j Level
			LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
			org.apache.logging.log4j.core.config.Configuration config = ctx.getConfiguration();

			LoggerConfig loggerConfig = null;
			loggerConfig = config.getLoggerConfig(LogManager.ROOT_LOGGER_NAME);
			loggerConfig.setLevel(level);

			String[] debugLibraries = debugPackages.split(",");

			for (String packageName : debugLibraries) {

				loggerConfig = config.getLoggerConfig(packageName);
				loggerConfig.setLevel(level);
			}

			ctx.updateLoggers();
		} catch (Throwable th) {

			th.printStackTrace();
		}
	}

}
