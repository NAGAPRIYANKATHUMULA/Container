/*
 * RequestHeader.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.model.common.composite;

import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;

/**
 * <HTML> This is the RequestHeader POJO</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since Oct 25 2016
 */
public class RequestHeader {

	/** The consumer. */
	private Consumer consumer;

	/** The credentials. */
	private Credentials credentials;
	
	/** The transaction id. */
	private String transactionId;

	/**
	 * Gets the consumer.
	 *
	 * @return the consumer
	 */
	public Consumer getConsumer() {
		return consumer;
	}

	/**
	 * Sets the consumer.
	 *
	 * @param consumer the new consumer
	 */
	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}

	/**
	 * Gets the credentials.
	 *
	 * @return the credentials
	 */
	public Credentials getCredentials() {
		return credentials;
	}

	/**
	 * Sets the credentials.
	 *
	 * @param credentials the new credentials
	 */
	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}

	/**
	 * Gets the transaction id.
	 *
	 * @return the transaction id
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * Sets the transaction id.
	 *
	 * @param transactionId the new transaction id
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	

}
