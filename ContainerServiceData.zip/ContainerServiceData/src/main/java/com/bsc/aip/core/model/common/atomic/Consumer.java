/*
 * Consumer.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.model.common.atomic;

/**
 * <HTML> This is the Consumer POJO</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since Oct 25 2016
 */
public class Consumer {

	/** The name. */
	private String name;

	/** The id. */
	private String id;

	/** The business unit. */
	private String businessUnit;

	/** The type. */
	private String type;

	/** The client version. */
	private String clientVersion;

	/** The request date time. */
	private String requestDateTime;

	/**
	 * Host name of the consumer
	 */
	private String hostName;

	/**
	 * The business transaction type
	 */
	private String businessTransactionType;

	/**
	 * The context ID
	 */
	private String contextId;

	/**
	 * The secondary context ID
	 */
	private String secondContextId;

	/**
	 * The third context ID
	 */
	private String thirdContextId;

	/**
	 * Gets the client version.
	 *
	 * @return the client version
	 */
	public String getClientVersion() {
		return clientVersion;
	}

	/**
	 * Sets the client version.
	 *
	 * @param clientVersion
	 *            the new client version
	 */
	public void setClientVersion(String clientVersion) {
		this.clientVersion = clientVersion;
	}

	/**
	 * Gets the request date time.
	 *
	 * @return the request date time
	 */
	public String getRequestDateTime() {
		return requestDateTime;
	}

	/**
	 * Sets the request date time.
	 *
	 * @param requestDateTime
	 *            the new request date time
	 */
	public void setRequestDateTime(String requestDateTime) {
		this.requestDateTime = requestDateTime;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name
	 *            the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id
	 *            the new id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Gets the business unit.
	 *
	 * @return the business unit
	 */
	public String getBusinessUnit() {
		return businessUnit;
	}

	/**
	 * Sets the business unit.
	 *
	 * @param businessUnit
	 *            the new business unit
	 */
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type
	 *            the new type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return hostName
	 */
	public String getHostName() {
		return hostName;
	}

	/**
	 * @param hostName
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	/**
	 * @return businessTransactionType
	 */
	public String getBusinessTransactionType() {
		return businessTransactionType;
	}

	/**
	 * @param businessTransactionType
	 */
	public void setBusinessTransactionType(String businessTransactionType) {
		this.businessTransactionType = businessTransactionType;
	}

	/**
	 * @return contextId
	 */
	public String getContextId() {
		return contextId;
	}

	/**
	 * @param contextId
	 */
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}

	/**
	 * @return secondContextId
	 */
	public String getSecondContextId() {
		return secondContextId;
	}

	/**
	 * @param secondContextId
	 */
	public void setSecondContextId(String secondContextId) {
		this.secondContextId = secondContextId;
	}

	/**
	 * @return thirdContextId
	 */
	public String getThirdContextId() {
		return thirdContextId;
	}

	/**
	 * @param thirdContextId
	 */
	public void setThirdContextId(String thirdContextId) {
		this.thirdContextId = thirdContextId;
	}

}
