/*
 * CustomCamelContextNameStrategy.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.framewrok.config;


import java.util.concurrent.atomic.AtomicInteger;

import org.apache.camel.spi.CamelContextNameStrategy;

/**
 * <HTML> A default name strategy which auto assigns a name using a prefix-counter pattern.</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since oct 25 2016
 */
public class CustomCamelContextNameStrategy implements CamelContextNameStrategy {
	
	
   private static final AtomicInteger CONTEXT_COUNTER = new AtomicInteger(0);
   private final String prefix;
   private String name;

   public CustomCamelContextNameStrategy() {
       this("camel");
   }

   public CustomCamelContextNameStrategy(String prefix) {
       this.prefix = prefix;
       this.name = getNextName();
   }

  
   /* (non-Javadoc)
    * @see org.apache.camel.spi.CamelContextNameStrategy#getName()
    */
   public String getName() {
       if (name == null) {
           name = getNextName();
       }
       return name;
   }

   
   public static AtomicInteger getContextCounter() {
	return CONTEXT_COUNTER;
}

public String getPrefix() {
	return prefix;
}

public void setName(String name) {
	this.name = name;
}

public String getNextName() {
       return prefix + "-" + getNextCounter();
   }

  
   public boolean isFixedName() {
       return false;
   }

   public static int getNextCounter() {
       // we want to start counting from 1, so increment first
       return CONTEXT_COUNTER.incrementAndGet();
   }

   /**
    * To reset the counter, should only be used for testing purposes.
    *
    * @param value the counter value
    */
   public static void setCounter(int value) {
       CONTEXT_COUNTER.set(value);
   }

}
