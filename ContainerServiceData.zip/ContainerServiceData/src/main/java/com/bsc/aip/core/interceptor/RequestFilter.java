/*
 * RequestFilter.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2016 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.interceptor;


public class RequestFilter  {
	
	private static final String SWAGGER_JWT = "bsc_ais_198133_swagger_2.0";
	
	//TODO:This class will be removed 
}
