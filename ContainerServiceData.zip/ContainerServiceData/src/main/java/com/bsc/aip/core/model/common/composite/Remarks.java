/*
 * Remarks.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.model.common.composite;

import java.util.ArrayList;
import java.util.List;

import com.bsc.aip.core.model.common.atomic.Message;

/**
 * <HTML> This is the Remarks POJO</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since Oct 25 2016
 */
public class Remarks {

	/** The message. */
	private List<Message> messages = new ArrayList<Message>();

	/**
	 * Gets the messages.
	 *
	 * @return the messages
	 */
	public List<Message> getMessages() {
		return messages;
	}

	/**
	 * Sets the messages.
	 *
	 * @param message the new messages
	 */
	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();

		sb.append("Remarks {");

		for (Message message : messages) {

			sb.append(message.toString());
		}

		sb.append("}");

		return sb.toString();
	}

}
