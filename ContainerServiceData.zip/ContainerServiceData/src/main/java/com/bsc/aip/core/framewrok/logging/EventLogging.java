/*
 * EventLogging.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.framewrok.logging;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.model.common.composite.EventLogRequest;
import com.bsc.aip.core.model.common.composite.Remarks;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.util.CoreUtil;

/**
 * <HTML>This class contains the functions to perform event logging for the
 * service</HTML>
 * 
 * @author AIP
 * @version 1.0
 * @since Jan 09 2017
 *
 */
@Component("eventLogging")
@EnableAsync
public class EventLogging {

	private static final Logger LOGGER = LogManager.getLogger(EventLogging.class);

	@Value("${eventlog.url}")
	private String eventLogUrl;

	private RestTemplate restTemplate = new RestTemplate();

	@Async
	@SuppressWarnings("unchecked")
	public void logEvent(RequestHeader requestHeader, ResponseHeader responseHeader, String type, String subType,
			String eventErrCd, String eventErrDesc, String eventErrSevCd, String eventExcStackTrac,
			String serviceName) {

		JSONObject eventLogObj = new JSONObject();

		String status = null;

		String tranSourceCd = null;
		String transactionId = null;
		String tranHostname = null;
		String busTransTypCd = null;
		String contextId = null;
		String secContextId = null;
		String thirdContextId = null;
		String additionalDetail = null;

		String hostName = null;

		hostName = CoreUtil.getServiceHost();
		boolean isValidRegDt = false;
		String requestDateTime = null;

		if (requestHeader != null && requestHeader.getConsumer() != null) {

			tranHostname = requestHeader.getConsumer().getHostName();
			busTransTypCd = requestHeader.getConsumer().getBusinessTransactionType();
			requestDateTime = requestHeader.getConsumer().getRequestDateTime();
			transactionId = requestHeader.getTransactionId();
			contextId = requestHeader.getConsumer().getContextId();
			secContextId = requestHeader.getConsumer().getSecondContextId();
			thirdContextId = requestHeader.getConsumer().getThirdContextId();
			if (StringUtils.isNotBlank(requestDateTime)) {
				isValidRegDt = CoreUtil.isValidDateFormat(requestDateTime, "yyyy-MM-dd HH:mm:ss:SSS");
			}

			if (StringUtils.isNotBlank(requestHeader.getConsumer().getName())) {
				tranSourceCd = requestHeader.getConsumer().getName();
			}
		}

		if (responseHeader != null && responseHeader.getTransactionNotification() != null) {

			if (StringUtils.isNotBlank(responseHeader.getTransactionNotification().getStatus())) {

				status = responseHeader.getTransactionNotification().getStatus();
			}

			if (responseHeader.getTransactionNotification().getRemarks() != null) {
				Remarks remark = responseHeader.getTransactionNotification().getRemarks();

				if (remark.getMessages() != null && !remark.getMessages().isEmpty()) {
					additionalDetail = remark.toString();
				}

			}
		}

		eventLogObj.put(EventLogRequest.EVENT_TYPE_CODE, type);
		eventLogObj.put(EventLogRequest.EVENT_SUBTYPE_CODE, subType);
		eventLogObj.put(EventLogRequest.TRANSACTION_SOURCE_CODE, tranSourceCd);
		eventLogObj.put(EventLogRequest.TRANSACTION_SOURCE_HOST_NAME, tranHostname);
		eventLogObj.put(EventLogRequest.BUSINESS_TRANSACTION_TYPE_CODE, busTransTypCd);
		eventLogObj.put(EventLogRequest.BUSINESS_SERVICE_HOSTNAME, hostName);
		eventLogObj.put(EventLogRequest.ADDITIONAL_DETAIL, additionalDetail);
		eventLogObj.put(EventLogRequest.TRANSACTION_ID, transactionId);
		if (isValidRegDt) {
			eventLogObj.put(EventLogRequest.EVENT_CREATE_TIME, requestDateTime);
		} else {
			eventLogObj.put(EventLogRequest.EVENT_CREATE_TIME,
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS").format(new Date()));
		}
		eventLogObj.put(EventLogRequest.CONTEXT_ID, contextId);
		eventLogObj.put(EventLogRequest.SECOND_CONTEXT_ID, secContextId);
		eventLogObj.put(EventLogRequest.THIRD_CONTEXT_ID, thirdContextId);
		eventLogObj.put(EventLogRequest.EVENT_ORIGINATOR_COMPONENT, serviceName);
		eventLogObj.put(EventLogRequest.EVENT_STATUS_CODE, status);

		if ("BUSINESS".equals(type) || "EXCEPTION".equals(type)) {

			eventLogObj.put(EventLogRequest.EVENT_ERROR_SEVERITY_CODE, eventErrSevCd);
			eventLogObj.put(EventLogRequest.EVENT_ERROR_CODE, eventErrCd);
			eventLogObj.put(EventLogRequest.EVENT_ERROR_DESC, eventErrDesc);
			eventLogObj.put(EventLogRequest.EVENT_EXCEPTION_TRACE, eventExcStackTrac);

		}

		sendEventLogRequest(eventLogObj);

	}

	/**
	 **
	 * <HTML>
	 * <h1>Method to send event log request</h1>
	 * <p>
	 * This method sends an asynchronous request to AIS event logging service
	 * </p>
	 * <HTML>.
	 *
	 * @param eventLogObj
	 * 
	 **/
	private void sendEventLogRequest(JSONObject eventLogObj) {

		try {

			HttpEntity<String> requestEntity = new HttpEntity<String>((String) eventLogObj.toJSONString());

			getRestTemplate().exchange(getEventLogUrl(), HttpMethod.POST, requestEntity, HttpStatus.class);

		} catch (Exception ex) {
			LOGGER.error("Exception occurred while logging event. Exception is {}", ex.getMessage());
		}
	}

	/**
	 * @return Event log URL
	 */
	public String getEventLogUrl() {
		return eventLogUrl;
	}

	/**
	 * @param eventLogUrl
	 */
	public void setEventLogUrl(String eventLogUrl) {
		this.eventLogUrl = eventLogUrl;
	}

	/**
	 * @return restTemplate
	 */
	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

	/**
	 * @param restTemplate
	 */
	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

}
