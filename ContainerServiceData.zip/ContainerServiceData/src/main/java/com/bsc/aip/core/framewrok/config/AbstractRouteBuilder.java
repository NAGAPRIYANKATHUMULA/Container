/*
 * AbstractRouteBuilder.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.framewrok.config;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;

/**
 * <HTML> This class is base class for routes. Contains global exception
 * handler</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since Feb 16 2017
 */
public abstract class AbstractRouteBuilder extends RouteBuilder {

	/**
	 * Default exception handling for all routes.
	 *
	 * @throws Exception
	 */
	@Override
	public void configure() throws Exception {

		// servlet is configured in web.xml
		restConfiguration().component("servlet").bindingMode(RestBindingMode.json_xml);			

	}
}
