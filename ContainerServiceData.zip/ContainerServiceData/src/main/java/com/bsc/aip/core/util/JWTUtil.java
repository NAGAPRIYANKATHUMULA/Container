package com.bsc.aip.core.util;

import java.security.Key;
import java.util.Date;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.impl.TextCodec;

public class JWTUtil {

	public static String generateJWT(String secretKey) {
		// We need a signing key, so we'll create one just for this example.
		// Usually
		// the key would be read from your application configuration instead.

		String compactJws = Jwts.builder().setSubject("BlueshieldCA").signWith(SignatureAlgorithm.HS256, secretKey) // TextCodec.BASE64.encode(secretKey)
				.compact();

		return compactJws;
	}

	public static boolean validateJWT(String compactJws, String secretKey) {

		try {

			Claims claims = Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(secretKey))
					.parseClaimsJws(compactJws).getBody();

			// OK, we can trust this JWT
			return true;

		} catch (Throwable e) {
			e.printStackTrace();
			return false;
			// don't trust the JWT!
		}
	}

	// Sample method to construct a JWT
	public static String createJWT(String id, String issuer, String subject, long ttlMin, String apiKey) {

		long ttlMillis = ttlMin * 60 * 1000; // Convert Min to Mills

		// The JWT signature algorithm we will be using to sign the token
		SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);

		// We will sign our JWT with our ApiKey secret
		byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(apiKey); // Already
																				// encoded
																				// by
																				// TextCodec.BASE64.encode
		Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

		// Let's set the JWT Claims
		JwtBuilder builder = Jwts.builder().setId(id).setIssuedAt(now).setSubject(subject).setIssuer(issuer)
				.signWith(signatureAlgorithm, signingKey);

		// if it has been specified, let's add the expiration
		if (ttlMillis >= 0) {
			long expMillis = nowMillis + ttlMillis;
			Date exp = new Date(expMillis);
			builder.setExpiration(exp);
		}

		// Builds the JWT and serializes it to a compact, URL-safe string
		return builder.compact();
	}

	 public static void main(String[] args) {
		 
		String base64EncodedSecretKey = "QERpZ2l0YWwgSW5kZXBlbnQgVGVjaG5vbG9naWVzIDIwMTdA"; 
		
		String base64EncodedWrongKey = "QERpZ2l0YWTgSW5kZXBlbnQgVGVjaG5vbG9naWVzIDIwMTdA"; 

		String jwt = createJWT("ServiceDesktop_BlueshieldCA", "BlueshieldCA", "Blue Shiled of California", 365,
				base64EncodedSecretKey);
		System.out.println("JWT:" + jwt);
		
		boolean validity1 = validateJWT(jwt,base64EncodedSecretKey);
		
		System.out.println("validity1:" + validity1);
		
		boolean validity2 = validateJWT(jwt,base64EncodedWrongKey);
		
		System.out.println("validity2:" + validity2);
		
		
	}

}
