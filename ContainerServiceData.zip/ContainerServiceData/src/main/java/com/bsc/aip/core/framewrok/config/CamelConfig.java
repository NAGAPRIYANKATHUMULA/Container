/*
 * CamelConfig.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.framewrok.config;

import org.apache.camel.CamelContext;

import org.apache.camel.component.metrics.routepolicy.MetricsRoutePolicyFactory;
import org.apache.camel.spring.javaconfig.CamelConfiguration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
/**
 * <HTML> This class contains the Camel configuration</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since Oct 25 2016
 */
@Configuration
@Component
public class CamelConfig extends CamelConfiguration {
	
	/** The api name. */
	@Value("${container.name}")
	private String apiName;
	
	/** The debug packages. */
	@Value("${logger.debug.libraries}")
	private String debugPackages;
	
	/** The logger level */
	@Value("${container.log.level}")
	private String logLevel;
	
	/* (non-Javadoc)
	 * @see org.apache.camel.spring.javaconfig.CamelConfiguration#setupCamelContext(org.apache.camel.CamelContext)
	 */
	@Override
	protected void setupCamelContext(CamelContext camelContext) {

		try {
		
			LogConfig.setupLog4J(debugPackages, logLevel);
			
			CustomCamelContextNameStrategy camelContextNameStrategy = new CustomCamelContextNameStrategy();
			
			camelContextNameStrategy.setName(apiName);
			
			camelContext.addRoutePolicyFactory(new MetricsRoutePolicyFactory());
			
			camelContext.setNameStrategy(camelContextNameStrategy);
			
			super.setupCamelContext(camelContext);


		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
