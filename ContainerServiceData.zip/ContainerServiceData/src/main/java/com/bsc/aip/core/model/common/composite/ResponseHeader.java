/*
 * ResponseHeader.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.aip.core.model.common.composite;

/**
 * <HTML> This is the ResponseHeader POJO</HTML>.
 *
 * @author AIP
 * @version 1.0
 * @since Oct 25 2016
 */
public class ResponseHeader {

	/** The transaction notification. */
	private TransactionNotification transactionNotification = new TransactionNotification();

	/**
	 * Gets the transaction notification.
	 *
	 * @return the transaction notification
	 */
	public TransactionNotification getTransactionNotification() {
		return transactionNotification;
	}

	/**
	 * Sets the transaction notification.
	 *
	 * @param transactionNotification
	 *            the new transaction notification
	 */
	public void setTransactionNotification(TransactionNotification transactionNotification) {
		this.transactionNotification = transactionNotification;
	}

}
